from flask import Flask, render_template, url_for, request, redirect

from flask_login import LoginManager, login_required

from models import User, obter_conexao

login_manager = LoginManager()
app = Flask(__name__)
app.config['SECRET_KEY'] = 'SUPERMEGABLASTERDIFICIL'
login_manager.init_app(app)

# quando precisar saber qual o usuário conectado 
# temos como calcular
@login_manager.user_loader
def load_user(user_id):
    return User.get(user_id)

@app.route('/')
def index():
    return "Oi"

@app.route('/login')
def login():
    if request.method == "POST":
        email = request.form['email']
        senha = request.form['senha']

        user = User.get_by_email(email)

@app.route('/dash')
@login_required
def dash():
    return "Você não deveria estar aqui, filho"